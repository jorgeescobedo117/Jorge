package main

import (
	"crypto/aes"
	"crypto/cipher"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// La misma clave estática utilizada en el ransomware
var hardcodedKey = []byte("ByChatGPT1234567")

// Función para remover el relleno PKCS#7 aplicado durante el cifrado
func pkcs7Unpad(data []byte) ([]byte, error) {
	length := len(data)
	if length == 0 {
		return nil, fmt.Errorf("datos vacíos")
	}
	padding := int(data[length-1])
	if padding > length || padding > aes.BlockSize {
		return nil, fmt.Errorf("relleno PKCS#7 inválido")
	}
	// Comprobar que todos los bytes de relleno sean correctos
	for i := 0; i < padding; i++ {
		if data[length-1-i] != byte(padding) {
			return nil, fmt.Errorf("bytes de relleno incorrectos")
		}
	}
	return data[:length-padding], nil
}

// Función para descifrar un archivo individual con AES-CBC
func decryptFile(filePath string, key []byte) error {
	ciphertext, err := os.ReadFile(filePath)
	if err != nil {
		return err
	}

	// Comprobar que el archivo al menos contenga el tamaño del bloque del IV (16 bytes)
	if len(ciphertext) < aes.BlockSize {
		return fmt.Errorf("el archivo es demasiado corto para estar cifrado")
	}

	// 1. Extraer el IV (primeros 16 bytes)
	iv := ciphertext[:aes.BlockSize]
	actualCiphertext := ciphertext[aes.BlockSize:]

	// 2. Inicializar el descifrador AES
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}

	// 3. Descifrar en modo CBC
	mode := cipher.NewCBCDecrypter(block, iv)
	plaintext := make([]byte, len(actualCiphertext))
	mode.CryptBlocks(plaintext, actualCiphertext)

	// 4. Quitar el relleno PKCS#7
	plaintext, err = pkcs7Unpad(plaintext)
	if err != nil {
		return err
	}

	// 5. Sobrescribir el archivo con los datos originales restaurados
	return os.WriteFile(filePath, plaintext, 0644)
}

// Evitar rutas críticas del sistema por seguridad
func isCriticalPath(path string) bool {
	lowerPath := strings.ToLower(path)
	return strings.Contains(lowerPath, `c:\windows`) ||
		strings.Contains(lowerPath, `c:\program files`) ||
		strings.Contains(lowerPath, `c:\program files (x86)`)
}

// Recorrer los directorios y descifrar los ficheros afectados
func decryptFiles(rootDir string, extensions []string, key []byte) error {
	err := filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if isCriticalPath(path) {
			if info.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		// Si encontramos la nota de rescate dejada por el ransomware, la eliminamos
		if !info.IsDir() && filepath.Base(path) == "README_DECRYPT.txt" {
			fmt.Println("Eliminando nota de rescate:", path)
			_ = os.Remove(path)
			return nil
		}

		if info.IsDir() {
			return nil
		}

		for _, ext := range extensions {
			if strings.HasSuffix(strings.ToLower(path), strings.ToLower(ext)) {
				fmt.Println("Descifrando:", path)
				if decErr := decryptFile(path, key); decErr != nil {
					fmt.Printf("Error al descifrar %s: %v\n", path, decErr)
				}
				break
			}
		}
		return nil
	})

	return err
}

func main() {
	// Las mismas extensiones que cifró el ransomware
	extensions := []string{".jpg", ".docx", ".xlsx", ".pptx", ".pdf", ".png"}

	rootDir, err := os.Getwd()
	if err != nil {
		panic(err)
	}

	fmt.Println("Iniciando proceso de vacunación y recuperación en:", rootDir)

	if err := decryptFiles(rootDir, extensions, hardcodedKey); err != nil {
		panic(err)
	}

	fmt.Println("¡Proceso finalizado! Todos los archivos recuperados y notas eliminadas.")
}